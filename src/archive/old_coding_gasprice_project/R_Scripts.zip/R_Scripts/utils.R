


put_date_information_in_dt <- function(data) {
  data[, ":="(
    year = year(date), month = month(date),
    quarter = quarter(date)
  )]
}

# helper function to get datetime from 'date' in csvs
get_dt <- \(date) fastPOSIXct(date) - as.integer(substr(date, 22, 22)) * 3600L


read_prices_csv <- function(chunk, get_time_info = FALSE) {
  # Function to read a chunk of csv files
  col_types <- cols(
    date = col_character(),
    station_uuid = col_character(),
    diesel = col_double(), e5 = col_double(),
    e10 = col_double(),
    dieselchange = col_integer(),
    e5change = col_integer(),
    e10change = col_integer()
  )
  out <- vroom::vroom(
    chunk,
    col_types = col_types,
    # id = "path",
    altrep = TRUE,
    delim = ",",
    progress = FALSE
  ) |>
    setDT() |>
    setnames("station_uuid", "id") |>
    DT(, dt := get_dt(date)) |>
    DT(, date := NULL) |>
    setcolorder(c("id", "dt"))
  if (get_time_info) {
    tz <- "Europe/Berlin"
    out |>
      DT(, year := year(dt)) |>
      DT(, month := month(dt)) |>
      DT(, hour := hour(dt)) |>
      DT(, time := as.ITime(dt, tz = tz)) |>
      DT(, date := as.IDate(dt, tz = tz))
  }
  return(out)
}


group_by_size <- function(x, size) {
  s <- 0
  out <- integer(length(x))
  value <- 0L
  for (i in seq_along(x)) {
    s <- s + x[i]
    out[i] <- value
    if (s > size) {
      value <- value + 1
      s <- 0
    }
  }
  return(out)
}